/**
 * Page Modifier — Content Script
 * Handles all real-time DOM modifications on the active page.
 */

(function () {
  'use strict';

  // ─── State ────────────────────────────────────────────────────────────────
  const PM = {
    editMode: false,
    soundEnabled: true,
    undoStack: [],
    maxUndo: 50,
    hoveredEl: null,
    darkModeActive: false,
  };

  // ─── Utility: Push to undo stack ──────────────────────────────────────────
  function pushUndo(action) {
    PM.undoStack.push(action);
    if (PM.undoStack.length > PM.maxUndo) PM.undoStack.shift();
  }

  // ─── Utility: Toast notification ──────────────────────────────────────────
  function showToast(message, icon = '✏️', duration = 2500) {
    const existing = document.querySelector('.pm-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'pm-toast';
    toast.innerHTML = `<span class="pm-toast-icon">${icon}</span><span>${message}</span>`;
    document.body.appendChild(toast);

    if (PM.soundEnabled) playSound('notify');

    setTimeout(() => {
      toast.classList.add('pm-toast-exit');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  // ─── Utility: Play sound ──────────────────────────────────────────────────
  function playSound(type) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'notify') {
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1100, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.2);
      } else if (type === 'click') {
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.1);
      }
    } catch (e) { /* Silently ignore audio errors */ }
  }

  // ─── Edit Mode: Toggle ────────────────────────────────────────────────────
  function setEditMode(enabled) {
    PM.editMode = enabled;
    if (enabled) {
      document.body.classList.add('pm-edit-mode');
      document.addEventListener('mouseover', onMouseOver);
      document.addEventListener('mouseout', onMouseOut);
      document.addEventListener('click', onElementClick, true);
      showToast('Edit Mode ON — click any element to edit', '🖊️');
    } else {
      document.body.classList.remove('pm-edit-mode');
      document.removeEventListener('mouseover', onMouseOver);
      document.removeEventListener('mouseout', onMouseOut);
      document.removeEventListener('click', onElementClick, true);
      if (PM.hoveredEl) {
        PM.hoveredEl.classList.remove('pm-highlight');
        PM.hoveredEl = null;
      }
      showToast('Edit Mode OFF', '⏹️');
    }
  }

  // ─── Edit Mode: Mouse handlers ────────────────────────────────────────────
  function onMouseOver(e) {
    const el = e.target;
    if (isSystemElement(el)) return;
    if (PM.hoveredEl && PM.hoveredEl !== el) {
      PM.hoveredEl.classList.remove('pm-highlight');
    }
    el.classList.add('pm-highlight');
    PM.hoveredEl = el;
  }

  function onMouseOut(e) {
    const el = e.target;
    if (el) el.classList.remove('pm-highlight');
  }

  function isSystemElement(el) {
    return el.classList.contains('pm-highlight') ||
      el.classList.contains('pm-toast') ||
      el.classList.contains('pm-overlay') ||
      el.closest('.pm-overlay') ||
      el.closest('.pm-image-modal') ||
      el.tagName === 'HTML' ||
      el.tagName === 'BODY';
  }

  // ─── Edit Mode: Click handler ─────────────────────────────────────────────
  function onElementClick(e) {
    if (!PM.editMode) return;
    const el = e.target;
    if (isSystemElement(el)) return;

    e.preventDefault();
    e.stopPropagation();

    if (PM.soundEnabled) playSound('click');

    if (el.tagName === 'IMG') {
      openImageModal(el);
    } else {
      openTextEditor(el);
    }
  }

  // ─── Text Editor ──────────────────────────────────────────────────────────
  function openTextEditor(el) {
    const originalText = el.innerText || el.textContent;
    const originalHTML = el.innerHTML;

    // Make element directly editable
    el.contentEditable = 'true';
    el.classList.remove('pm-highlight');
    el.focus();

    // Select all text
    const range = document.createRange();
    range.selectNodeContents(el);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    function finishEdit() {
      el.contentEditable = 'false';
      el.removeEventListener('blur', finishEdit);
      el.removeEventListener('keydown', onKeyDown);

      const newText = el.innerText || el.textContent;
      if (newText !== originalText) {
        pushUndo({
          type: 'text',
          el,
          oldHTML: originalHTML,
          newHTML: el.innerHTML,
        });
        showToast('Text updated!', '✅');
      }
    }

    function onKeyDown(e) {
      if (e.key === 'Escape') {
        el.innerHTML = originalHTML;
        el.contentEditable = 'false';
        el.removeEventListener('blur', finishEdit);
        el.removeEventListener('keydown', onKeyDown);
        showToast('Edit cancelled', '↩️');
      }
      // Enter without shift commits
      if (e.key === 'Enter' && !e.shiftKey && el.tagName !== 'DIV' && el.tagName !== 'P') {
        e.preventDefault();
        el.blur();
      }
    }

    el.addEventListener('blur', finishEdit);
    el.addEventListener('keydown', onKeyDown);
  }

  // ─── Image Modal ──────────────────────────────────────────────────────────
  function openImageModal(imgEl) {
    const overlay = document.createElement('div');
    overlay.className = 'pm-overlay';

    overlay.innerHTML = `
      <div class="pm-image-modal">
        <h3>🖼️ Replace Image</h3>
        <label style="font-size:13px;color:#6b7280;font-weight:600;display:block;margin-bottom:6px;">Image URL</label>
        <input type="text" id="pm-img-url" placeholder="https://example.com/image.jpg" />
        <div class="pm-modal-divider">— or —</div>
        <label style="font-size:13px;color:#6b7280;font-weight:600;display:block;margin-bottom:6px;">Upload from device</label>
        <input type="file" id="pm-img-file" accept="image/*" />
        <div class="pm-modal-buttons">
          <button class="pm-btn pm-btn-secondary" id="pm-img-cancel">Cancel</button>
          <button class="pm-btn pm-btn-primary" id="pm-img-apply">Apply</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    const urlInput = overlay.querySelector('#pm-img-url');
    const fileInput = overlay.querySelector('#pm-img-file');
    const applyBtn = overlay.querySelector('#pm-img-apply');
    const cancelBtn = overlay.querySelector('#pm-img-cancel');

    urlInput.focus();

    function applyImage(src) {
      const oldSrc = imgEl.src;
      imgEl.src = src;
      pushUndo({ type: 'image', el: imgEl, oldSrc, newSrc: src });
      overlay.remove();
      showToast('Image replaced!', '🖼️');
    }

    applyBtn.addEventListener('click', () => {
      const url = urlInput.value.trim();
      if (url) {
        applyImage(url);
        return;
      }
      const file = fileInput.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => applyImage(e.target.result);
        reader.readAsDataURL(file);
        return;
      }
      showToast('Please enter a URL or choose a file', '⚠️');
    });

    cancelBtn.addEventListener('click', () => overlay.remove());

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove();
    });

    // Enter key submits
    urlInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') applyBtn.click();
    });
  }

  // ─── Preset: Comic Sans ───────────────────────────────────────────────────
  function applyComicSans() {
    const els = document.querySelectorAll('*:not(script):not(style)');
    const changed = [];
    els.forEach(el => {
      if (el.children.length === 0 || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        const old = el.style.fontFamily;
        el.style.fontFamily = '"Comic Sans MS", "Comic Sans", cursive';
        changed.push({ el, old });
      }
    });
    // Also apply to body
    const bodyOld = document.body.style.fontFamily;
    document.body.style.fontFamily = '"Comic Sans MS", "Comic Sans", cursive';
    pushUndo({
      type: 'preset',
      name: 'comicSans',
      undo: () => {
        changed.forEach(({ el, old }) => el.style.fontFamily = old);
        document.body.style.fontFamily = bodyOld;
      }
    });
    showToast('Everything is now Comic Sans 😂', '🎨');
  }

  // ─── Preset: Replace all images with cats ─────────────────────────────────
  function replaceWithCats() {
    const imgs = document.querySelectorAll('img');
    const changed = [];
    imgs.forEach((img, i) => {
      const oldSrc = img.src;
      const w = img.naturalWidth || img.width || 400;
      const h = img.naturalHeight || img.height || 300;
      img.src = `https://cataas.com/cat?width=${w}&height=${h}&t=${Date.now()}_${i}`;
      changed.push({ img, oldSrc });
    });
    pushUndo({
      type: 'preset',
      name: 'cats',
      undo: () => changed.forEach(({ img, oldSrc }) => img.src = oldSrc)
    });
    showToast(`Replaced ${imgs.length} images with cats! 🐱`, '🐱');
  }

  // ─── Preset: Emoji text ───────────────────────────────────────────────────
  const EMOJI_MAP = {
    'the': '👉', 'and': '➕', 'is': '✅', 'are': '🌟', 'was': '⏪',
    'be': '🐝', 'to': '2️⃣', 'a': '🅰️', 'in': '📥', 'of': '🔵',
    'that': '👆', 'it': '💡', 'for': '4️⃣', 'on': '🔛', 'with': '🤝',
    'he': '👦', 'she': '👧', 'they': '👥', 'we': '👫', 'you': '👤',
    'have': '✋', 'this': '☝️', 'from': '📤', 'or': '🔀', 'an': '🅰️➕',
    'but': '🍑', 'not': '🚫', 'by': '👋', 'at': '@', 'as': '🅰️💲',
    'love': '❤️', 'happy': '😊', 'sad': '😢', 'good': '👍', 'bad': '👎',
    'yes': '✅', 'no': '❌', 'ok': '👌', 'hi': '👋', 'hello': '👋',
    'world': '🌍', 'time': '⏰', 'day': '📅', 'night': '🌙', 'sun': '☀️',
    'money': '💰', 'food': '🍕', 'water': '💧', 'fire': '🔥', 'star': '⭐',
    'home': '🏠', 'work': '💼', 'play': '🎮', 'music': '🎵', 'art': '🎨',
  };

  function applyEmojiText() {
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT'].includes(parent.tagName))
            return NodeFilter.FILTER_REJECT;
          if (parent.classList.contains('pm-toast') || parent.closest('.pm-overlay'))
            return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const nodes = [];
    let node;
    while ((node = walker.nextNode())) nodes.push(node);

    const changed = [];
    nodes.forEach(textNode => {
      const original = textNode.textContent;
      let replaced = original;
      Object.entries(EMOJI_MAP).forEach(([word, emoji]) => {
        const regex = new RegExp(`\\b${word}\\b`, 'gi');
        replaced = replaced.replace(regex, emoji);
      });
      if (replaced !== original) {
        textNode.textContent = replaced;
        changed.push({ node: textNode, original });
      }
    });

    pushUndo({
      type: 'preset',
      name: 'emoji',
      undo: () => changed.forEach(({ node, original }) => node.textContent = original)
    });
    showToast('Text converted to emojis! 🎉', '😜');
  }

  // ─── Preset: Dark mode override ───────────────────────────────────────────
  function toggleDarkMode() {
    PM.darkModeActive = !PM.darkModeActive;
    document.documentElement.classList.toggle('pm-dark-mode', PM.darkModeActive);
    pushUndo({
      type: 'preset',
      name: 'darkMode',
      undo: () => {
        PM.darkModeActive = false;
        document.documentElement.classList.remove('pm-dark-mode');
      }
    });
    showToast(PM.darkModeActive ? 'Dark mode ON 🌙' : 'Dark mode OFF ☀️',
      PM.darkModeActive ? '🌙' : '☀️');
  }

  // ─── Find & Replace ───────────────────────────────────────────────────────
  function findAndReplace(find, replace) {
    if (!find) return 0;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT'].includes(parent.tagName))
            return NodeFilter.FILTER_REJECT;
          if (parent.closest('.pm-overlay') || parent.closest('.pm-toast'))
            return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const nodes = [];
    let node;
    while ((node = walker.nextNode())) nodes.push(node);

    let count = 0;
    const changed = [];

    nodes.forEach(textNode => {
      const original = textNode.textContent;
      try {
        const regex = new RegExp(escapeRegex(find), 'gi');
        const matches = original.match(regex);
        if (matches) {
          const newText = original.replace(regex, replace);
          textNode.textContent = newText;
          count += matches.length;
          changed.push({ node: textNode, original });
        }
      } catch (e) { /* Skip invalid regex */ }
    });

    if (count > 0) {
      pushUndo({
        type: 'findReplace',
        find,
        replace,
        undo: () => changed.forEach(({ node, original }) => node.textContent = original)
      });
      showToast(`Replaced ${count} occurrence${count !== 1 ? 's' : ''} of "${find}"`, '🔍');
    } else {
      showToast(`No occurrences of "${find}" found`, '🔍');
    }

    return count;
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // ─── Undo ─────────────────────────────────────────────────────────────────
  function undo() {
    if (PM.undoStack.length === 0) {
      showToast('Nothing to undo', '↩️');
      return;
    }

    const action = PM.undoStack.pop();

    switch (action.type) {
      case 'text':
        action.el.innerHTML = action.oldHTML;
        showToast('Text change undone', '↩️');
        break;
      case 'image':
        action.el.src = action.oldSrc;
        showToast('Image change undone', '↩️');
        break;
      case 'preset':
      case 'findReplace':
        if (typeof action.undo === 'function') action.undo();
        showToast('Change undone', '↩️');
        break;
    }
  }

  // ─── Reset Page ───────────────────────────────────────────────────────────
  function resetPage() {
    window.location.reload();
  }

  // ─── Apply Saved Preset ───────────────────────────────────────────────────
  function applyPreset(preset) {
    if (!preset || !preset.actions) return;

    preset.actions.forEach(action => {
      switch (action.type) {
        case 'findReplace':
          findAndReplace(action.find, action.replace);
          break;
        case 'comicSans':
          applyComicSans();
          break;
        case 'cats':
          replaceWithCats();
          break;
        case 'emoji':
          applyEmojiText();
          break;
        case 'darkMode':
          if (!PM.darkModeActive) toggleDarkMode();
          break;
      }
    });

    showToast(`Preset "${preset.name}" applied!`, '⚡');
  }

  // ─── Message listener (from popup) ────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.action) {
      case 'setEditMode':
        setEditMode(msg.enabled);
        sendResponse({ ok: true });
        break;

      case 'getEditMode':
        sendResponse({ enabled: PM.editMode });
        break;

      case 'preset_comicSans':
        applyComicSans();
        sendResponse({ ok: true });
        break;

      case 'preset_cats':
        replaceWithCats();
        sendResponse({ ok: true });
        break;

      case 'preset_emoji':
        applyEmojiText();
        sendResponse({ ok: true });
        break;

      case 'preset_darkMode':
        toggleDarkMode();
        sendResponse({ ok: true });
        break;

      case 'findReplace':
        const count = findAndReplace(msg.find, msg.replace);
        sendResponse({ count });
        break;

      case 'undo':
        undo();
        sendResponse({ ok: true });
        break;

      case 'reset':
        resetPage();
        sendResponse({ ok: true });
        break;

      case 'applyPreset':
        applyPreset(msg.preset);
        sendResponse({ ok: true });
        break;

      case 'setSoundEnabled':
        PM.soundEnabled = msg.enabled;
        sendResponse({ ok: true });
        break;

      case 'ping':
        sendResponse({ pong: true });
        break;
    }
    return true; // Keep message channel open for async
  });

  // ─── Init: Restore state if page was modified before ──────────────────────
  chrome.storage.local.get(['pm_editMode', 'pm_soundEnabled'], (data) => {
    if (data.pm_soundEnabled === false) PM.soundEnabled = false;
    // Don't auto-enable edit mode on page load — user must toggle it
  });

})();
