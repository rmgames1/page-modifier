/**
 * Page Modifier — Background Service Worker (Manifest V3)
 * Handles extension lifecycle events and tab management.
 */

'use strict';

// ─── Install / Update ─────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Page Modifier installed successfully!');
    // Set default settings
    chrome.storage.local.set({
      pm_soundEnabled: true,
      pm_editMode: false,
      pm_savedPresets: [],
    });
  } else if (details.reason === 'update') {
    console.log(`Page Modifier updated to version ${chrome.runtime.getManifest().version}`);
  }
});

// ─── Tab navigation: reset edit mode state when navigating ────────────────
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    // Reset edit mode in storage when page navigates
    chrome.storage.local.set({ pm_editMode: false });
  }
});

// ─── Context menu (optional enhancement) ─────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getTabId') {
    sendResponse({ tabId: sender.tab?.id });
  }
  return true;
});
