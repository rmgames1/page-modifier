/**
 * Page Modifier — Popup Script
 * Handles all popup UI interactions, state management, and messaging to content script.
 */

(function () {
  'use strict';

  // ─── State ────────────────────────────────────────────────────────────────
  let soundEnabled = true;
  let editModeActive = false;
  let pendingActions = []; // Track actions for preset saving
  let savedPresets = [];

  // ─── DOM References ───────────────────────────────────────────────────────
  const toggleEditMode = document.getElementById('toggle-edit-mode');
  const editModeHint = document.getElementById('edit-mode-hint');
  const btnSound = document.getElementById('btn-sound');
  const btnUndo = document.getElementById('btn-undo');
  const btnReset = document.getElementById('btn-reset');
  const findInput = document.getElementById('find-input');
  const replaceInput = document.getElementById('replace-input');
  const btnFindReplace = document.getElementById('btn-find-replace');
  const replaceResult = document.getElementById('replace-result');
  const presetNameInput = document.getElementById('preset-name-input');
  const btnSavePreset = document.getElementById('btn-save-preset');
  const savedPresetsList = document.getElementById('saved-presets-list');
  const emptyPresets = document.getElementById('empty-presets');

  // ─── Utility: Send message to active tab ──────────────────────────────────
  async function sendToTab(message) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return null;

      // Ensure content script is injected
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
        if (!response?.pong) throw new Error('No pong');
      } catch {
        // Inject content script if not already there
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
        await chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ['content.css']
        });
      }

      return await chrome.tabs.sendMessage(tab.id, message);
    } catch (err) {
      console.error('Page Modifier: Failed to send message', err);
      return null;
    }
  }

  // ─── Utility: Show inline feedback ────────────────────────────────────────
  function showResult(el, message, type = 'success') {
    el.textContent = message;
    el.className = 'replace-result' + (type === 'error' ? ' error' : '');
    setTimeout(() => {
      el.textContent = '';
      el.className = 'replace-result';
    }, 3000);
  }

  // ─── Utility: Button feedback animation ───────────────────────────────────
  function flashButton(btn, successText, originalText, duration = 1500) {
    btn.textContent = successText;
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = originalText;
      btn.disabled = false;
    }, duration);
  }

  // ─── Init: Load state from storage ────────────────────────────────────────
  async function init() {
    const data = await chrome.storage.local.get([
      'pm_soundEnabled',
      'pm_savedPresets',
      'pm_editMode'
    ]);

    soundEnabled = data.pm_soundEnabled !== false;
    savedPresets = data.pm_savedPresets || [];
    editModeActive = data.pm_editMode || false;

    updateSoundButton();
    toggleEditMode.checked = editModeActive;
    editModeHint.classList.toggle('visible', editModeActive);

    renderSavedPresets();

    // Sync edit mode state with content script
    const response = await sendToTab({ action: 'getEditMode' });
    if (response) {
      editModeActive = response.enabled;
      toggleEditMode.checked = editModeActive;
      editModeHint.classList.toggle('visible', editModeActive);
    }
  }

  // ─── Sound toggle ─────────────────────────────────────────────────────────
  function updateSoundButton() {
    btnSound.textContent = soundEnabled ? '🔊' : '🔇';
    btnSound.title = soundEnabled ? 'Sound ON (click to mute)' : 'Sound OFF (click to enable)';
  }

  btnSound.addEventListener('click', async () => {
    soundEnabled = !soundEnabled;
    updateSoundButton();
    await chrome.storage.local.set({ pm_soundEnabled: soundEnabled });
    await sendToTab({ action: 'setSoundEnabled', enabled: soundEnabled });
  });

  // ─── Edit Mode toggle ─────────────────────────────────────────────────────
  toggleEditMode.addEventListener('change', async () => {
    editModeActive = toggleEditMode.checked;
    editModeHint.classList.toggle('visible', editModeActive);
    await chrome.storage.local.set({ pm_editMode: editModeActive });
    await sendToTab({ action: 'setEditMode', enabled: editModeActive });
  });

  // ─── Undo ─────────────────────────────────────────────────────────────────
  btnUndo.addEventListener('click', async () => {
    await sendToTab({ action: 'undo' });
  });

  // ─── Reset ────────────────────────────────────────────────────────────────
  btnReset.addEventListener('click', async () => {
    if (confirm('Reset the page? All unsaved changes will be lost.')) {
      editModeActive = false;
      toggleEditMode.checked = false;
      editModeHint.classList.remove('visible');
      await chrome.storage.local.set({ pm_editMode: false });
      await sendToTab({ action: 'reset' });
      window.close();
    }
  });

  // ─── Quick Presets ────────────────────────────────────────────────────────
  const presetButtons = document.querySelectorAll('.preset-btn');
  presetButtons.forEach(btn => {
    btn.addEventListener('click', async () => {
      const action = btn.dataset.action;
      if (!action) return;

      btn.classList.add('active');
      setTimeout(() => btn.classList.remove('active'), 600);

      const result = await sendToTab({ action });

      // Track for preset saving
      const actionMap = {
        preset_comicSans: { type: 'comicSans' },
        preset_cats: { type: 'cats' },
        preset_emoji: { type: 'emoji' },
        preset_darkMode: { type: 'darkMode' },
      };
      if (actionMap[action]) {
        pendingActions.push(actionMap[action]);
      }
    });
  });

  // ─── Find & Replace ───────────────────────────────────────────────────────
  btnFindReplace.addEventListener('click', async () => {
    const find = findInput.value.trim();
    const replace = replaceInput.value;

    if (!find) {
      showResult(replaceResult, '⚠️ Please enter text to find', 'error');
      findInput.focus();
      return;
    }

    const result = await sendToTab({ action: 'findReplace', find, replace });

    if (result !== null) {
      if (result.count > 0) {
        showResult(replaceResult, `✅ Replaced ${result.count} occurrence${result.count !== 1 ? 's' : ''}`);
        // Track for preset saving
        pendingActions.push({ type: 'findReplace', find, replace });
        findInput.value = '';
        replaceInput.value = '';
      } else {
        showResult(replaceResult, `🔍 No matches found for "${find}"`, 'error');
      }
    } else {
      showResult(replaceResult, '⚠️ Could not reach page. Try refreshing.', 'error');
    }
  });

  // Allow Enter key in find input
  findInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') btnFindReplace.click();
  });
  replaceInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') btnFindReplace.click();
  });

  // ─── Save Preset ──────────────────────────────────────────────────────────
  btnSavePreset.addEventListener('click', async () => {
    const name = presetNameInput.value.trim();
    if (!name) {
      presetNameInput.focus();
      presetNameInput.style.borderColor = '#ef4444';
      setTimeout(() => presetNameInput.style.borderColor = '', 1500);
      return;
    }

    if (pendingActions.length === 0) {
      // Save current find/replace if inputs are filled
      const find = findInput.value.trim();
      const replace = replaceInput.value;
      if (find) {
        pendingActions.push({ type: 'findReplace', find, replace });
      } else {
        presetNameInput.style.borderColor = '#ef4444';
        setTimeout(() => presetNameInput.style.borderColor = '', 1500);
        showResult(replaceResult, '⚠️ Apply some changes first before saving', 'error');
        return;
      }
    }

    const preset = {
      id: Date.now().toString(),
      name,
      actions: [...pendingActions],
      createdAt: new Date().toLocaleDateString(),
    };

    savedPresets.unshift(preset);
    await chrome.storage.local.set({ pm_savedPresets: savedPresets });

    pendingActions = [];
    presetNameInput.value = '';
    renderSavedPresets();
    flashButton(btnSavePreset, '✅ Saved!', 'Save');
  });

  // ─── Render Saved Presets ─────────────────────────────────────────────────
  function renderSavedPresets() {
    // Clear existing items (except empty state)
    const items = savedPresetsList.querySelectorAll('.preset-item');
    items.forEach(item => item.remove());

    if (savedPresets.length === 0) {
      emptyPresets.style.display = 'flex';
      return;
    }

    emptyPresets.style.display = 'none';

    savedPresets.forEach(preset => {
      const item = document.createElement('div');
      item.className = 'preset-item';
      item.dataset.id = preset.id;

      const actionSummary = summarizeActions(preset.actions);

      item.innerHTML = `
        <div class="preset-item-name" title="${escapeHtml(preset.name)}">${escapeHtml(preset.name)}</div>
        <div class="preset-item-meta">${actionSummary}</div>
        <div class="preset-item-actions">
          <button class="preset-item-btn apply" title="Apply preset">▶</button>
          <button class="preset-item-btn delete" title="Delete preset">✕</button>
        </div>
      `;

      const applyBtn = item.querySelector('.apply');
      const deleteBtn = item.querySelector('.delete');

      applyBtn.addEventListener('click', async () => {
        applyBtn.textContent = '✓';
        await sendToTab({ action: 'applyPreset', preset });
        setTimeout(() => applyBtn.textContent = '▶', 1000);
      });

      deleteBtn.addEventListener('click', async () => {
        savedPresets = savedPresets.filter(p => p.id !== preset.id);
        await chrome.storage.local.set({ pm_savedPresets: savedPresets });
        item.style.animation = 'fade-out 0.2s ease forwards';
        setTimeout(() => renderSavedPresets(), 200);
      });

      savedPresetsList.appendChild(item);
    });
  }

  function summarizeActions(actions) {
    if (!actions || actions.length === 0) return '0 actions';
    const types = actions.map(a => {
      switch (a.type) {
        case 'comicSans': return 'Comic Sans';
        case 'cats': return 'Cats';
        case 'emoji': return 'Emojis';
        case 'darkMode': return 'Dark Mode';
        case 'findReplace': return `"${a.find}"→"${a.replace}"`;
        default: return a.type;
      }
    });
    const summary = types.slice(0, 2).join(', ');
    return actions.length > 2 ? `${summary} +${actions.length - 2}` : summary;
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ─── Boot ─────────────────────────────────────────────────────────────────
  init();

})();
